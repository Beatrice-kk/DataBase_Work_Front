<template>
    <div class="login-container">
        <div class="background-wrapper">
            <img :src="login_background" :style="backgroundStyle" />
        </div>
        <div class="worker-wrapper">
            <img :src="worker" :style="workerStyle" />
        </div>
        <el-card class="login-box">
            <div class="login-header">
                <h2 class="system-title">学生成绩管理系统</h2>
                <h3 class="login-subtitle">账户登录</h3>
            </div>
            <div class="login-form">
                <el-select
                    v-model="value"
                    placeholder="请选择用户类型"
                    class="login-select"
                >
                    <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                    />
                </el-select>
                <el-input
                    v-model="username"
                    class="login-input"
                    placeholder="请输入用户名"
                    prefix-icon="User"
                />
                <el-input
                    v-model="password"
                    type="password"
                    class="login-input"
                    placeholder="请输入密码"
                    prefix-icon="Lock"
                    show-password
                />
                <el-button @click="login" class="login-button">
                    登录
                </el-button>
            </div>
        </el-card>
    </div>
</template>

<script>
import axios from "axios";
import request from "@/api/request";
import { ElMessage } from "element-plus";

export default {
    data() {
        return {
            value: "Manager", // 默认选择管理员
            username: "",
            password: "",
            login_background: require("@/assets/img/login_background.png"),
            options: [
                { value: "Student", label: "学生" },
                { value: "Teacher", label: "教师" },
                { value: "Manager", label: "管理员" },
            ],
        };
    },
    computed: {
        backgroundStyle() {
            return {
                position: "fixed",
                top: "0",
                left: "0",
                width: "100vw",
                height: "100vh",
                objectFit: "cover",
                zIndex: "-1",
            };
        },
    },
    methods: {
        async login() {
            if (this.value === "Manager") {
                this.admin_login();
            } else if (this.value === "Teacher") {
                this.teacher_login();
            } else if (this.value === "Student") {
                this.student_login();
            }
        },
        async admin_login() {
            try {
                const params = new URLSearchParams();
                params.append("id", this.username);
                params.append("password", this.password);

                const response = await request.post("/api/admin/login", params);
                console.log(response.data); // 打印接收到的数据

                if (response.data.code === 200) {
                    // 检查 code 字段
                    const token = response.data.data;
                    sessionStorage.setItem("Authorization", token); // 存储到 sessionStorage
                    this.$router.push("/admin/home");
                } else {
                    ElMessage.error("Login failed: " + response.data.msg);
                }
            } catch (error) {
                console.error("Error during login:", error);
                ElMessage.error(" occurred. Please try again.");
            }
        },
        async teacher_login() {
            try {
                const params = new URLSearchParams();
                params.append("id", this.username);
                params.append("password", this.password);

                const response = await request.post(
                    "/api/teacher/login",
                    params
                );
                console.log(response.data); // 打印接收到的数据
                if (response.data.code === 200) {
                    // 检查 code 字段
                    const token = response.data.data;
                    sessionStorage.setItem("Authorization", token); // 存储到 sessionStorage
                    this.$router.push("/teacher/home");
                } else {
                    ElMessage.error("Login failed: " + response.data.msg);
                }
            } catch (error) {
                console.error("Error during login:", error);
                ElMessage.error("An error occurred. Please try again.");
            }
        },
        async student_login() {
            try {
                const params = new URLSearchParams();
                params.append("id", this.username);
                params.append("password", this.password);

                const response = await request.post(
                    "/api/student/login",
                    params
                );
                console.log(response.data); // 打印接收到的数据
                if (response.data.code === 200) {
                    // 检查 code 字段
                    const token = response.data.data;
                    sessionStorage.setItem("Authorization", token); // 存储到 sessionStorage
                    this.$router.push("/student/home");
                } else {
                    ElMessage.error("Login failed: " + response.data.msg);
                }
            } catch (error) {
                console.error("Error during login:", error);
                ElMessage.error("An error occurred. Please try again.");
            }
        },
        keyDown(e) {
            if (e.keyCode === 13) {
                this.login();
                document.removeEventListener("keydown", this.keyDown);
            }
        },
    },
    mounted() {
        window.addEventListener("keydown", this.keyDown);
    },
    beforeDestroy() {
        window.removeEventListener("keydown", this.keyDown);
    },
};
</script>

<style scoped>
.login-container {
    position: relative;
    width: 100vw;
    height: 100vh;
    overflow: hidden;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
}

.background-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    z-index: 1;
}

.background-wrapper img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    opacity: 0.3;
}

.worker-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    z-index: 2;
}

.login-box {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 400px;
    padding: 40px;
    background: rgba(255, 255, 255, 0.95);
    border-radius: 20px;
    box-shadow: 0 20px 60px rgba(163, 97, 220, 0.2);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(163, 97, 220, 0.1);
    z-index: 10;
    transition: all 0.3s ease;
}

.login-box:hover {
    transform: translate(-50%, -50%) translateY(-5px);
    box-shadow: 0 30px 80px rgba(163, 97, 220, 0.3);
}

.login-header {
    text-align: center;
    margin-bottom: 30px;
}

.system-title {
    font-size: 28px;
    font-weight: 700;
    color: #a361dc;
    margin: 0 0 10px 0;
    text-shadow: 0 2px 4px rgba(163, 97, 220, 0.1);
}

.login-subtitle {
    font-size: 18px;
    font-weight: 500;
    color: #666;
    margin: 0;
    opacity: 0.8;
}

.login-form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.login-select,
.login-input {
    width: 100%;
}

.login-select :deep(.el-input__wrapper) {
    background: rgba(163, 97, 220, 0.05);
    border: 2px solid rgba(163, 97, 220, 0.1);
    border-radius: 12px;
    transition: all 0.3s ease;
}

.login-select :deep(.el-input__wrapper:hover) {
    border-color: rgba(163, 97, 220, 0.3);
    box-shadow: 0 0 0 2px rgba(163, 97, 220, 0.1);
}

.login-select :deep(.el-input__wrapper.is-focus) {
    border-color: #a361dc;
    box-shadow: 0 0 0 2px rgba(163, 97, 220, 0.2);
}

.login-input :deep(.el-input__wrapper) {
    background: rgba(163, 97, 220, 0.05);
    border: 2px solid rgba(163, 97, 220, 0.1);
    border-radius: 12px;
    transition: all 0.3s ease;
}

.login-input :deep(.el-input__wrapper:hover) {
    border-color: rgba(163, 97, 220, 0.3);
    box-shadow: 0 0 0 2px rgba(163, 97, 220, 0.1);
}

.login-input :deep(.el-input__wrapper.is-focus) {
    border-color: #a361dc;
    box-shadow: 0 0 0 2px rgba(163, 97, 220, 0.2);
}

.login-input :deep(.el-input__inner) {
    color: #333;
    font-weight: 500;
}

.login-input :deep(.el-input__prefix) {
    color: #a361dc;
}

.login-button {
    width: 100%;
    height: 48px;
    background: linear-gradient(135deg, #a361dc 0%, #8b5cf6 100%);
    border: none;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 600;
    color: rgb(189, 53, 53);
    transition: all 0.3s ease;
    margin-top: 10px;
}

.login-button:hover {
    background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(163, 97, 220, 0.4);
}

.login-button:active {
    transform: translateY(0);
}

/* 响应式设计 */
@media (max-width: 768px) {
    .login-box {
        width: 90%;
        max-width: 350px;
        padding: 30px 25px;
    }

    .system-title {
        font-size: 24px;
    }

    .login-subtitle {
        font-size: 16px;
    }
}
</style>
