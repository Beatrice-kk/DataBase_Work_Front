<template>
    <Navigation>
        <div class="home-view">
            <el-row>
                <el-col :span="24">
                    <h1>欢迎你进入学生信息管理系统</h1>
                    <el-text class="large-text">{{ input }}</el-text>
                </el-col>
            </el-row>
        </div>
        <div class="main-container">
            <div class="calendar-section">
                <el-calendar v-model="value" />
            </div>
            <!-- 中间：考试信息 -->
            <div class="exam-section">
                <el-card class="exam-info-card">
                    <template #header>
                        <div class="card-header">
                            <span>📘 考试信息</span>
                        </div>
                    </template>
                    <div v-if="allexam.length > 0" class="exam-list">
                        <div
                            v-for="(exam, index) in allexam"
                            :key="index"
                            class="exam-item"
                        >
                            <div class="exam-course">课程: {{ exam.name }}</div>
                            <div class="exam-time">
                                考试时间:{{ formatExamDate(exam.examDate) }}
                            </div>
                            <div class="exam-location" v-if="exam.location">
                                地点: {{ exam.location }}
                            </div>
                            <el-divider v-if="index < allexam.length - 1" />
                        </div>
                    </div>
                    <div v-else class="no-exam">暂无考试信息</div>
                </el-card>
            </div>
            <div class="action-section">
                <!-- 快捷操作 -->
                <el-card class="styled-card">
                    <div class="card-title">⚙️ 快捷操作</div>
                </el-card>
                <el-card class="styled-card">
                    <el-button
                        type="success"
                        @click="
                            clear_data2();
                            dialog2Visible = true;
                        "
                        class="full-btn"
                    >
                        添加管理员
                    </el-button>
                </el-card>
                <el-card class="styled-card">
                    <el-button
                        type="primary"
                        @click="
                            clear_data();
                            dialogVisible = true;
                        "
                        class="full-btn"
                    >
                        修改密码
                    </el-button>
                </el-card>
            </div>

            <!-- 修改密码对话框 -->
            <el-dialog
                title="修改密码"
                v-model="dialogVisible"
                width="400px"
                class="styled-dialog"
            >
                <el-form
                    ref="form"
                    :model="form"
                    :rules="rules"
                    label-width="80px"
                >
                    <el-form-item label="旧密码" prop="oldpass">
                        <el-input
                            v-model="form.oldpass"
                            show-password
                        ></el-input>
                    </el-form-item>
                    <el-form-item label="新密码" prop="newpass">
                        <el-input
                            v-model="form.newpass"
                            show-password
                        ></el-input>
                    </el-form-item>
                </el-form>
                <template #footer>
                    <el-button @click="clear_data()">取消</el-button>
                    <el-button
                        type="primary"
                        @click="
                            changepassword();
                            clear_data();
                        "
                        >确定</el-button
                    >
                </template>
            </el-dialog>

            <!-- 添加管理员对话框 -->
            <el-dialog
                title="添加管理员账号"
                v-model="dialog2Visible"
                width="400px"
                class="styled-dialog"
            >
                <el-form
                    ref="form2"
                    :model="form2"
                    :rules="rules2"
                    label-width="100px"
                >
                    <el-form-item label="管理员账号" prop="account">
                        <el-input v-model="form2.account"></el-input>
                    </el-form-item>
                    <el-form-item label="密码" prop="password">
                        <el-input
                            v-model="form2.password"
                            show-password
                        ></el-input>
                    </el-form-item>
                </el-form>
                <template #footer>
                    <el-button @click="clear_data2()">取消</el-button>
                    <el-button
                        type="primary"
                        @click="
                            createAdmin();
                            clear_data2();
                        "
                        >确定</el-button
                    >
                </template>
            </el-dialog>
        </div>
    </Navigation>
</template>

<script>
import Navigation from "../components/Navigation.vue";
import api from "@/api/index.js";
import request from "@/api/request.js";

// import * as echarts from "echarts";
export default {
    name: "AdminHomeView",
    components: {
        Navigation,
    },
    data() {
        return {
            user_id: "",
            dialogVisible: false,
            dialog2Visible: false,
            input: " ",
            myChart: {},
            allexam: [],
            myChartStyle: { float: "left", width: "100%", height: "400px" },
            form: {
                oldpass: "",
                newpass: "",
            },
            form2: {
                account: "",
                password: "",
            },
            rules: {
                old_pass: [
                    {
                        required: true,
                        message: "请输入旧密码",
                        trigger: "blur",
                    },
                ],
                new_pass: [
                    {
                        required: true,
                        message: "请输入新密码",
                        trigger: "blur",
                    },
                ],
            },
            rules2: {
                old_pass: [
                    {
                        required: true,
                        message: "请输入管理员账号",
                        trigger: "blur",
                    },
                ],
                new_pass: [
                    { required: true, message: "请输入密码", trigger: "blur" },
                ],
            },
            value: new Date(),
            examMap: {}, // { "2024-07-12": { courseName: "高等数学", ... } }
        };
    },
    methods: {
        formatExamDate(datetimeStr) {
            if (!datetimeStr) return "";
            return datetimeStr.replace("T", " ");
        },
        clear_data() {
            this.form.oldpass = "";
            this.form.newpass = "";
            this.dialogVisible = false;
        },
        clear_data2() {
            this.form2.account = "";
            this.form2.password = "";
            this.dialog2Visible = false;
        },
        async changepassword() {
            try {
                const response = await api.adminChangePassword(
                    this.form.oldpass,
                    this.form.newpass
                );
                if (response.data.code === 200) {
                    this.$message.success("密码修改成功");
                } else {
                    this.$message.error("密码修改失败");
                }
            } catch (error) {
                console.error("请求失败", error);
                this.$message.error("请求过程中发生错误");
            }
        },
        async createAdmin() {
            const response = await api.addAdmin(
                this.form2.account,
                this.form2.password
            );
            if (response.data.code === 200) {
                this.$message.success("账号创建成功");
            } else {
                this.$message.error("账号创建失败");
            }
        },
        //-------------------------------
        //   getExamData() {
        //       api.fetchExamCourses()
        //           .then((res) => {
        //               const data = res.data.data || [];
        //               const map = {};
        //               data.forEach((item) => {
        //                   map[item.examDate] = item;
        //               });
        //               this.examMap = map;
        //               this.allexam = data;
        //               //   this.input = `今天是 ${new Date().toLocaleDateString()}，你有 ${
        //               //       data.length
        //               //   } 门考试。`;
        //           })
        //           .catch((err) => {
        //               console.error("获取考试信息失败", err);
        //           });
        //   },

        async getExamData() {
            try {
                const res = await api.fetchExamCourses();
                console.log(res);
                if (res.data.code === 200) {
                    const sortedData = res.data.data.sort(
                        (a, b) => new Date(a.examDate) - new Date(b.examDate)
                    );

                    this.allexam = sortedData;
                } else {
                    this.$message.error("获取考试信息失败");
                }
            } catch (error) {
                console.log("获取考试信息时发生错误", error);
            }
        },
        //---------------------
    },
    created() {},

    mounted() {
        this.getExamData();
    },

    //-----------
};
</script>

<style>
/* 页面整体布局 */
.action-section {
    padding: 20px;
}

.home-view {
    max-width: 100%;
    margin: 30px auto 0;
    text-align: center;
   color: #A361DC;

}

.large-text {
    font-size: 16px;
    color: #8B5CF6;
    margin-top: 10px;
    display: inline-block;
}

.home-layout {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin: 50px 100px;
    gap: 40px;
    flex-wrap: wrap;
}

/* 快捷操作卡片容器 */
.quick-actions {
    flex: 1;
    font-family: Arial, sans-serif;
    font-size: 20px;
    margin-top: 100px;
}

/* 通用卡片样式 */
.el-card {
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
    background-color: #fff;
}

.el-card h3,
.card-title {
    font-size: 26px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333;
}

.el-card .el-button,
.full-btn {
    height: 60px;
    width: 100%;
    margin-bottom: 12px;
    font-size: 26px;
    font-weight: bold;
    color: #fff;
    border: none;
    border-radius: 16px;
    background-image: linear-gradient(135deg, #409eff, #66b1ff);
    box-shadow: 0 6px 16px rgba(64, 158, 255, 0.3);
    transition: all 0.3s ease;
}

.el-card .el-button:hover,
.full-btn:hover {
    background-image: linear-gradient(135deg, #66b1ff, #409eff);
    box-shadow: 0 8px 20px rgba(64, 158, 255, 0.4);
    transform: translateY(-2px);
}

.el-card .el-button:active,
.full-btn:active {
    transform: translateY(1px);
    box-shadow: 0 4px 12px rgba(64, 158, 255, 0.25);
}

.calendar-section {
    flex: 2;
    padding: 10px;
    border-radius: 8px;
    box-shadow: 0 0 8px rgba(0, 0, 0, 0.05);
    background: #fff;
}
.exam-section {
    width: 40%;
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    padding: 20px;
}

.exam-info-card {
    height: 90%;
    overflow-y: auto;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.card-header span {
    font-size: 28px;
    font-weight: bold;
    color: #303133;
}

.exam-list {
    max-height: 400px;
    overflow-y: auto;
}

.exam-item {
    padding: 10px 0;
    line-height: 1.6;
}

.exam-course {
    font-size: 26px;
    font-weight: bold;
    color: #303133;
    margin-bottom: 5px;
}

.exam-time,
.exam-location {
    font-size: 24px;
    color: #606266;
}

.no-exam {
    text-align: center;
    color: #999;
    padding: 20px 0;
}

/* 表单项间距 */
.el-form-item {
    margin-bottom: 20px;
}

/* 弹窗样式 */
.el-dialog__body {
    padding-top: 10px;
}

.styled-dialog >>> .el-dialog {
    border-radius: 10px;
}
</style>
