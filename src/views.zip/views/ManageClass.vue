<template>
  <Navigation>
    <div class="home-view" activeIndex="1-4" key="nav">
      <el-row>
        <el-col :span="24">
          <h1>班级信息</h1>
        </el-col>
      </el-row>
      <el-button type="primary" @click="clearData(); dialogVisible = true; isEditing = false">
        添加班级信息
      </el-button>
    </div>

    <el-table :data="classData" stripe
      :style="{ width: '55%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-50%)' }">
      <el-table-column prop="id" label="班级ID" width="150"></el-table-column>
      <el-table-column prop="name" label="班级名称" width="250"></el-table-column>
      <el-table-column prop="collegeName" label="学院" width="200"></el-table-column>
      <el-table-column prop="majorName" label="专业" width="200"></el-table-column>
      <el-table-column prop="teacherName" label="班主任" width="150"></el-table-column>
      <el-table-column fixed="right" label="操作" min-width="160">
        <template #default="scope">
          <el-button link type="primary" size="small" @click="handleEdit(scope.row); isEditing = true">
            编辑
          </el-button>
          <el-button link type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="表单弹框" v-model="dialogVisible" width="30%">
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="班级ID" prop="id">
          <el-input v-model.number="form.id"></el-input>
        </el-form-item>
        <el-form-item label="班级名称" prop="name">
          <el-input v-model="form.name"></el-input>
        </el-form-item>
        <el-form-item label="学院" prop="collegeName">
          <el-select v-model="form.collegeName" placeholder="请选择学院" @change="fetchMajors">
            <el-option v-for="college in colleges" :key="college" :label="college" :value="college"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="专业" prop="majorName">
          <el-select v-model="form.majorName" placeholder="请选择专业" :disabled="!form.collegeName"
            @change="fetchTeachersByMajor">
            <el-option v-for="major in majors" :key="major" :label="major" :value="major"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="班主任" prop="teacherName">
          <el-select v-model="form.teacherName" placeholder="请选择班主任">
            <el-option v-for="teacher in filteredTeachers" :key="teacher.id" :label="teacher.name"
              :value="teacher.name">
              {{ teacher.name }} {{ teacher.id }}
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="clearData()">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </span>
    </el-dialog>

    <div class="demo-pagination-block"
      :style="{ width: '50%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-10%)' }">
      <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :total="total"
        layout="prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
    </div>
  </Navigation>
</template>

<script>
import Navigation from '../components/Navigation.vue'
import request from '../api/request'; // 引入预配置的axios实例
import api from '@/api/index'

export default {
  data() {
    return {
      isEditing: false,
      classData: [],
      dialogVisible: false,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      colleges: [],
      majors: [],
      teachers: [],
      filteredTeachers: [],
      form: {
        id: null,
        name: '',
        collegeName: '',
        majorName: '',
        teacherName: ''
      },
      rules: {
        id: [
          { required: true, message: '请输入班级ID', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入班级名称', trigger: 'blur' }
        ],
        collegeName: [
          { required: true, message: '请选择学院', trigger: 'blur' }
        ],
        majorName: [
          { required: true, message: '请选择专业', trigger: 'blur' }
        ],
        teacherName: [
          { required: true, message: '请选择班主任', trigger: 'blur' }
        ]
      }
    };
  },
  components: {
    Navigation,
  },
  methods: {
    async submitForm() {
      const formData = {
        id: this.form.id,
        name: this.form.name,
        college: this.form.collegeName,
        major: this.form.majorName,
        teacher_id: this.teachers.find(teacher => teacher.name === this.form.teacherName)?.id
      };
      try {
        let response;
        if (this.isEditing) {
          response = await request.put('/api/admin/class', formData);
        } else {
          response = await request.post('/api/admin/class', formData);
        }
        if (response.data.code === 200) {
          this.$message.success('操作成功');
          this.dialogVisible = false;
          this.fetchClass();
        } else {
          this.$message.error('操作失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('请求失败', error);
        this.$message.error('请求过程中发生错误');
      }
    },
    handleEdit(row) {
      this.form = { ...row };
      this.fetchMajors();
      this.fetchTeachersByMajor();
      this.dialogVisible = true;
    },
    async handleDelete(row) {
      try {
        const response = await api.deleteClass(row.id);
        if (response.data.code === 200) {
          this.$message.success('删除成功');
          this.fetchClass();
        } else {
          this.$message.error('删除失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('删除请求失败', error);
        this.$message.error('删除过程中发生错误');
      }
    },
    clearData() {
      this.form = {
        id: null,
        name: '',
        collegeName: '',
        majorName: '',
        teacherName: ''
      };
      this.dialogVisible = false;
    },
    handleSizeChange(size) {
      this.pageSize = size;
      this.fetchClass();
    },
    handleCurrentChange(page) {
      this.currentPage = page;
      this.fetchClass();
    },
    async fetchClass() {
      try {
        const response = await api.fetchClass(this.currentPage, this.pageSize, 'all', '');
        if (response.data.code === 200) {
          const classData = response.data.data.data;
          const majorCollegeMap = await this.fetchMajorCollegeMap(classData);
          this.classData = classData.map(cls => ({
            ...cls,
            collegeName: majorCollegeMap[cls.majorName] || '未知'
          }));
          this.total = response.data.data.total;
        } else {
          this.$message.error('获取班级数据失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('获取班级数据请求失败', error);
        this.$message.error('获取班级数据过程中发生错误');
      }
    },
    async fetchMajorCollegeMap(classData) {
      try {
        const majorNames = Array.from(new Set(classData.map(cls => cls.majorName)));
        const response = await api.fetchMajors(1, 100, 'all', '');
        if (response.data.code === 200 && response.data.data && response.data.data.data) {
          const majorCollegeMap = {};
          response.data.data.data.forEach(major => {
            if (majorNames.includes(major.name)) {
              majorCollegeMap[major.name] = major.collegeName;
            }
          });
          return majorCollegeMap;
        } else {
          this.$message.error('获取专业数据失败: ' + response.data.msg);
          return {};
        }
      } catch (error) {
        console.error('获取专业数据请求失败', error);
        this.$message.error('获取专业数据过程中发生错误');
        return {};
      }
    },
    async fetchColleges() {
      try {
        const response = await api.fetchDepartment(1, 100, 'all', '');
        if (response.data.code === 200) {
          this.colleges = response.data.data.data.map(option => option.name);
        } else {
          this.$message.error('获取学院数据失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('获取学院数据请求失败', error);
        this.$message.error('获取学院数据过程中发生错误');
      }
    },
    async fetchMajors() {
      if (!this.form.collegeName) {
        this.majors = [];
        return;
      }
      try {
        const response = await api.fetchMajors(1, 100, 'college', this.form.collegeName);
        if (response.data.code === 200) {
          this.majors = response.data.data.data.map(option => option.name);
        } else {
          this.$message.error('获取专业数据失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('获取专业数据请求失败', error);
        this.$message.error('获取专业数据过程中发生错误');
      }
      this.form.majorName = '';
      this.form.teacherName = '';
      this.filteredTeachers = [];
    },
    async fetchTeachers() {
      try {
        const response = await api.fetchTeachers(1, 100, 'all', '');
        if (response.data.code === 200) {
          this.teachers = response.data.data.data.map(teacher => ({
            name: teacher.name,
            id: teacher.id,
            major: teacher.major,
            college: teacher.college
          }));
        } else {
          this.$message.error('获取教师数据失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('获取教师数据请求失败', error);
        this.$message.error('获取教师数据过程中发生错误');
      }
    },
    fetchTeachersByMajor() {
      if (this.form.majorName) {
        this.filteredTeachers = this.teachers.filter(teacher => teacher.college === this.form.collegeName);
      } else {
        this.filteredTeachers = [];
      }
    }
  },
  async mounted() {
    await this.fetchClass();
    await this.fetchColleges();
    await this.fetchTeachers();
  },
}
</script>

<style scoped>
.home-view {
  padding: 20px;
}

.large-text {
  font-size: 20px;
}
</style>
