<template>
    <NavigationStu>
        <div class="home-view" activeIndex="1-4" key="nav">
            <el-row>
                <el-col :span="24">
                    <h1>查看所学课程</h1>
                </el-col>
            </el-row>
        </div>

        <el-table :data="courseData" stripe
            :style="{ width: '40%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-50%)' }">
            <el-table-column prop="course_id" label="课程编号" width="150"></el-table-column>
            <el-table-column prop="course_name" label="课程名称" width="150"></el-table-column>
            <el-table-column prop="teacher_id" label="教师编号" width="150"></el-table-column>
            <el-table-column prop="teacher_name" label="教师姓名" width="150"></el-table-column>
            <el-table-column prop="credit" label="学分" width="150"></el-table-column>
            <el-table-column prop="term" label="开设学期" width="150"></el-table-column>
            <el-table-column fixed="right" label="" min-width="10">
            </el-table-column>
        </el-table>

        <div class="demo-pagination-block"
            :style="{ width: '40%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-15%)' }">
            <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :total="total"
                layout="prev, pager, next, jumper" @size-change="handleSizeChange"
                @current-change="handleCurrentChange" />
        </div>
    </NavigationStu>
</template>

<script>
import NavigationStu from '../components/NavigationStu.vue'
import api from '@/api/index' // 确保此路径和您项目的API路径一致

export default {
    data() {
        return {
            currentPage: 1,
            pageSize: 10,
            courseData: [],
            total: 0,
            terms: ['2021-2022(1)', '2021-2022(2)', '2022-2023(1)', '2022-2023(2)', '2023-2024(1)', '2023-2024(2)', '2024-2025(1)', '2024-2025(2)']
        };
    },
    components: {
        NavigationStu,
    },
    methods: {
        handleSizeChange(size) {
            this.pageSize = size;
            this.fetchAllCourses();
        },
        handleCurrentChange(page) {
            this.currentPage = page;
            this.fetchAllCourses();
        },
        async fetchAllCourses() {
            this.courseData = [];
            try {
                for (let term of this.terms) {
                    const response = await api.studentGetCourse(this.currentPage, this.pageSize, term);
                    if (response.data.code === 200) {
                        this.courseData = this.courseData.concat(response.data.data.data);
                    } else {
                        this.$message.error('系统异常');
                    }
                }
                this.total = this.courseData.length;
            } catch (error) {
                console.error('Error during API call:', error);
            }
        }
    },
    mounted() {
        this.fetchAllCourses();
    }
}
</script>

<style scoped>
.home-view {
    padding: 20px;
}

.large-text {
    font-size: 20px;
}
</style>
