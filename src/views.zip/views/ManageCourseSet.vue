<template>
  <Navigation>
    <div class="home-view" activeIndex="1-4" key="nav">
      <el-row>
        <el-col :span="24">
          <h1>课表信息</h1>
          <el-text class="large-text">{{ input }}</el-text>
        </el-col>
      </el-row>
      <el-button type="primary" @click="clearData(); dialogVisible = true; isEditing = false">
        添加课表信息
      </el-button>
    </div>

    <el-table :data="coursesetData" stripe
      :style="{ width: '60%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-50%)' }">
      <el-table-column prop="course_id" label="课程编号" width="150"></el-table-column>
      <el-table-column prop="course_name" label="课程名称" width="220"></el-table-column>
      <el-table-column prop="class_name" label="班级名称" width="150"></el-table-column>
      <el-table-column prop="teacher_id" label="任课教师编号" width="150"></el-table-column>
      <el-table-column prop="teacher_name" label="任课教师姓名" width="150"></el-table-column>
      <el-table-column prop="year" label="开设学年" width="150"></el-table-column>
      <el-table-column prop="term" label="开设学期" width="150"></el-table-column>
      <el-table-column fixed="right" label="操作" min-width="160">
        <template #default="scope">
          <el-button link type="primary" size="small" @click="handleClick(scope.row); isEditing = true">
            编辑
          </el-button>
          <el-button link type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="表单弹框" v-model="dialogVisible" width="30%">
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="课程" prop="course">
          <el-select v-model="form.course_id" placeholder="请选择课程" @change="updateCourseInfo">
            <el-option v-for="course in courses" :key="course.id" :label="`${course.id} ${course.name}`"
              :value="course.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="班级名称" prop="class_name">
          <el-select v-model="form.class_name" placeholder="请选择班级">
            <el-option v-for="clazz in classes" :key="clazz.id" :label="clazz.name" :value="clazz.name"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="任课教师" prop="teacher_id">
          <el-select v-model="form.teacher_id" placeholder="请选择任课教师" @change="updateTeacherName">
            <el-option v-for="teacher in teachers" :key="teacher.id" :label="`${teacher.name} (${teacher.id})`"
              :value="teacher.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="开设学年" prop="year">
          <el-input v-model="form.year" disabled></el-input>
        </el-form-item>
        <el-form-item label="开设学期" prop="term">
          <el-input v-model="form.term" disabled></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="clearData()">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </span>
    </el-dialog>

    <div class="demo-pagination-block"
      :style="{ width: '50%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-10%)' }">
      <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :total="total"
        layout="prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
    </div>
  </Navigation>
</template>

<script>
import Navigation from '../components/Navigation.vue'
import api from '@/api/index'

export default {
  data() {
    return {
      isEditing: false,
      coursesetData: [],
      dialogVisible: false,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      teachers: [],
      courses: [],
      classes: [],
      form: {
        course_id: '',
        course_name: '',
        class_name: '',
        teacher_id: '',
        teacher_name: '',
        year: '',
        term: '',
      },
      rules: {
        course_id: [
          { required: true, message: '请选择课程', trigger: 'change' }
        ],
        class_name: [
          { required: true, message: '请选择班级', trigger: 'change' }
        ],
        teacher_id: [
          { required: true, message: '请选择任课教师', trigger: 'change' }
        ],
        year: [
          { required: true, message: '请输入开设学年', trigger: 'blur' }
        ],
        term: [
          { required: true, message: '请输入开设学期', trigger: 'blur' }
        ],
      }
    };
  },
  components: {
    Navigation,
  },
  methods: {
    async submitForm() {
      const formData = {
        course_id: this.form.course_id,
        course_name: this.form.course_name,
        class_name: this.form.class_name,
        teacher_id: this.form.teacher_id,
        teacher_name: this.form.teacher_name,
        year: this.form.year,
        term: this.form.term,
      };
      try {
        let response;
        if (this.isEditing) {
          response = await api.updateCourseset(formData);
        } else {
          response = await api.addCourseset(formData);
        }
        if (response.data.code === 200) {
          this.$message.success('操作成功');
          this.dialogVisible = false;
          this.fetchCourseset();
        } else {
          this.$message.error('操作失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('请求失败', error);
        this.$message.error('请求过程中发生错误');
      }
    },
    handleClick(row) {
      this.form = { ...row };
      this.dialogVisible = true;
    },
    async handleDelete(row) {
      const formData = {
        course_id: row.course_id,
        course_name: row.course_name,
        class_name: row.class_name,
        teacher_id: row.teacher_id,
        teacher_name: row.teacher_name,
        year: row.year,
        term: row.term,
      };
      try {
        const response = await api.deleteCourseset(formData);
        if (response.data.code === 200) {
          this.$message.success('删除成功');
          this.fetchCourseset();
        } else {
          this.$message.error('删除失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('删除请求失败', error);
        this.$message.error('删除过程中发生错误');
      }
    },
    clearData() {
      this.form = {
        course_id: '',
        course_name: '',
        class_name: '',
        teacher_id: '',
        teacher_name: '',
        year: '',
        term: '',
      };
      this.dialogVisible = false;
    },
    handleSizeChange(size) {
      this.pageSize = size;
      this.fetchCourseset();
    },
    handleCurrentChange(page) {
      this.currentPage = page;
      this.fetchCourseset();
    },
    async fetchCourseset() {
      try {
        const response = await api.fetchCourseset(this.currentPage, this.pageSize, 'all', '');
        if (response.data.code === 200) {
          this.coursesetData = response.data.data.data;
          this.total = response.data.data.total;
        } else {
          this.$message.error('获取课表数据失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('获取课表数据请求失败', error);
        this.$message.error('获取课表数据过程中发生错误');
      }
    },
    async fetchTeachers() {
      try {
        const response = await api.fetchTeachers(1, 100, 'all', '');
        if (response.data.code === 200) {
          this.teachers = response.data.data.data;
        } else {
          this.$message.error('获取教师数据失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('获取教师数据请求失败', error);
        this.$message.error('获取教师数据过程中发生错误');
      }
    },
    async fetchCourses() {
      try {
        const response = await api.fetchCourse(1, 100, 'all', '');
        if (response.data.code === 200) {
          this.courses = response.data.data.data;
        } else {
          this.$message.error('获取课程数据失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('获取课程数据请求失败', error);
        this.$message.error('获取课程数据过程中发生错误');
      }
    },
    async fetchClasses() {
      try {
        const response = await api.fetchClass(1, 100, 'all', '');
        if (response.data.code === 200) {
          this.classes = response.data.data.data;
        } else {
          this.$message.error('获取班级数据失败: ' + response.data.msg);
        }
      } catch (error) {
        console.error('获取班级数据请求失败', error);
        this.$message.error('获取班级数据过程中发生错误');
      }
    },
    updateTeacherName() {
      const selectedTeacher = this.teachers.find(teacher => teacher.id === this.form.teacher_id);
      this.form.teacher_name = selectedTeacher ? selectedTeacher.name : '';
    },
    updateCourseInfo() {
      const selectedCourse = this.courses.find(course => course.id === this.form.course_id);
      if (selectedCourse) {
        this.form.course_name = selectedCourse.name;
        this.form.year = selectedCourse.year;
        this.form.term = selectedCourse.term;
      } else {
        this.form.course_name = '';
        this.form.year = '';
        this.form.term = '';
      }
    }
  },
  async mounted() {
    this.fetchCourseset();
    this.fetchTeachers();
    this.fetchCourses();
    this.fetchClasses();
  }
}
</script>

<style scoped>
.home-view {
  padding: 20px;
}

.large-text {
  font-size: 20px;
}
</style>
