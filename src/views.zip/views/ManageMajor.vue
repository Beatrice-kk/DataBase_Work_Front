<template>
  <Navigation>
    <div class="home-view" activeIndex="1-4" key="nav">
      <el-row>
        <el-col :span="24">
          <h1>专业信息</h1>
          <el-text class="large-text">{{ input }}</el-text>
        </el-col>
      </el-row>
      <el-button type="primary" @click="clear_data(); dialogVisible = true; fix = false">
        添加专业信息
      </el-button>


    </div>

    <el-table :data="majorData" stripe
      :style="{ width: '35%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-50%)' }">
      <el-table-column prop="id" label="专业ID" width="150"></el-table-column>
      <el-table-column prop="name" label="专业名称" width="250"></el-table-column>
      <el-table-column prop="collegeName" label="学院" width="200"></el-table-column>
      <el-table-column fixed="right" label="操作" min-width="160">
        <template #default="scope">
          <el-button link type="primary" size="small" @click="handleClick(scope.row); fix = true">
            编辑
          </el-button>
          <el-button link type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>



    <el-dialog title="表单弹框" v-model="dialogVisible" width="30%">
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="专业ID" prop="id">
          <el-input v-model.number="form.id"></el-input>
        </el-form-item>
        <el-form-item label="专业名称" prop="name">
          <el-input v-model="form.name"></el-input>
        </el-form-item>
        <el-form-item label="学院名称" prop="collegeName">
          <el-input v-model="form.collegeName"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="clear_data()">取消</el-button>
        <el-button type="primary" @click="submitForm();">确定</el-button>
      </span>
    </el-dialog>

    <div class="demo-pagination-block"
      :style="{ width: '50%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-50%)' }">
      <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :size="size" :disabled="disabled"
        :background="background" layout="prev, pager, next, jumper" :total="total" @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :style="{ width: '50%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-20%)' }" />
    </div>



  </Navigation>
</template>

<script>
import Navigation from '../components/Navigation.vue'
import request from '../api/request'; // 引入预配置的axios实例
import api from '@/api/index'
export default {
  data() {
    return {
      fix: true,
      majorData: [],
      dialogVisible: false,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      form: {
        id: null,
        name: '',
        collegeName: ''
      },
      rules: {
        id: [
          { required: true, message: '请输入ID', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入专业名称', trigger: 'blur' }
        ],
        collegeName: [
          { required: true, message: '请输入学院名称', trigger: 'blur' }
        ]
      }
    };
  },
  components: {
    Navigation,
  },
  methods: {
    async submitForm() {
      const formData = {
        college: this.form.collegeName,
        name: this.form.name,
        id: parseInt(this.form.id),
      };
      if (this.fix !== true) {
        try {
          const response = await request.post('/api/admin/major', formData);
          if (response.data.code === 200) {
            this.$message.success('专业添加成功');
            // 可以在这里清空表单或执行其他操作
          } else {
            this.$message.error('添加失败: ' + response.data.msg);
          }
        } catch (error) {
          console.error('请求失败', error);
          this.$message.error('请求过程中发生错误');
        }
        this.clear_data()
        window.location.reload();
      } else {
        try {
          const response = await request.put('/api/admin/major', formData);
          if (response.data.code === 200) {
            this.$message.success('专业修改成功');
            // 可以在这里清空表单或执行其他操作
          } else {
            this.$message.error('修改失败: ' + response.data.msg);
          }
        } catch (error) {
          console.error('请求失败', error);
          this.$message.error('请求过程中发生错误');
        }
        this.clear_data()
        window.location.reload();
      }
    },


    handleClick(row) {
      this.currentRow = row; // 将当前行数据保存到data中的变量
      this.form.id = row.id;
      this.form.collegeName = row.collegeName;
      this.form.name = row.name;
      this.dialogVisible = true;
    },
    handleDelete(row) {
      api.deleteMajor(row.id)
      alert("删除成功")
      window.location.reload();
    },

    clear_data() {
      this.form.id = null;
      this.form.name = '';
      this.form.collegeName = '';
      this.dialogVisible = false;
    },
    handleSizeChange(size) {
      console.log(size)
      this.pageSize = size;
      this.fetchMajors(this.currentPage, this.pageSize);
    },
    handleCurrentChange(page) {
      console.log(page)
      this.currentPage = page;
      this.fetchMajors(this.currentPage, this.pageSize);
    },
    async fetchMajors() {
      try {
        const response = await api.fetchMajors(this.currentPage, this.pageSize, 'all', '');
        if (response.data.code === 200) {
          this.majorData = response.data.data.data;
          this.total = response.data.data.total
          console.log(this.majorData)
        } else {
          console.error('Failed to load teacher data:', response.data.msg);
        }
      } catch (error) {
        console.error('Error during API call:', error);
      }
    },
  },
  async mounted() {
    this.fetchMajors(this.currentPage, this.pageSize);
  },

}
</script>

<style scoped>
.home-view {
  padding: 20px;
}

.large-text {
  font-size: 20px;
}
</style>