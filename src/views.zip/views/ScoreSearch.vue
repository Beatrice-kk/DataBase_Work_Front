<template>
    <Navigation>
        <div class="home-view" activeIndex="1-4" key="nav">
            <el-row>
                <el-col :span="24">
                    <h1>成绩查询</h1>
                </el-col>
            </el-row>
        </div>

        <!-- 筛选条件输入框 -->
        <el-row :gutter="20" class="filter-row"
            :style="{ width: '50%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-20%)' }">
            <el-col :span="6">
                <el-select v-model="selectedTerm" placeholder="选择学期">
                    <el-option label="2021-2022(1)" value="2021-2022(1)"></el-option>
                    <el-option label="2021-2022(2)" value="2021-2022(2)"></el-option>
                    <el-option label="2022-2023(1)" value="2022-2023(1)"></el-option>
                    <el-option label="2022-2023(2)" value="2022-2023(2)"></el-option>
                    <el-option label="2023-2024(1)" value="2023-2024(1)"></el-option>
                    <el-option label="2023-2024(2)" value="2023-2024(2)"></el-option>
                    <el-option label="2024-2025(1)" value="2024-2025(1)"></el-option>
                    <el-option label="2024-2025(2)" value="2024-2025(2)"></el-option>
                </el-select>
            </el-col>
            <el-col :span="4">
                <el-button type="primary" @click="fetchScore">查询</el-button>
            </el-col>
        </el-row>

        <el-table :data="resultData" stripe
            :style="{ width: '60%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-50%)' }">
            <el-table-column prop="course_id" label="课程编号" width="150"></el-table-column>
            <el-table-column prop="course_name" label="课程名称" width="180"></el-table-column>
            <el-table-column prop="teacher_id" label="教师编号" width="150"></el-table-column>
            <el-table-column prop="teacher_name" label="教师姓名" width="150"></el-table-column>
            <el-table-column prop="student_id" label="学生学号" width="150"></el-table-column>
            <el-table-column prop="student_name" label="学生姓名" width="150"></el-table-column>
            <el-table-column prop="score" label="成绩" width="150"></el-table-column>
            <el-table-column prop="retake" label="是否重修" width="150"></el-table-column>
            <el-table-column fixed="right" label="" min-width="10">
            </el-table-column>
        </el-table>

        <div class="demo-pagination-block"
            :style="{ width: '50%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-15%)' }">
            <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :total="total"
                layout="prev, pager, next, jumper" @size-change="handleSizeChange"
                @current-change="handleCurrentChange" />
        </div>
    </Navigation>
</template>

<script>
import Navigation from '../components/Navigation.vue'
import api from '@/api/index' // 确保此路径和您项目的API路径一致

export default {
    data() {
        return {
            selectedTerm: '',
            selectedType: '',
            selectedOption: '',
            options: [],
            resultData: [],
            currentPage: 1,
            pageSize: 10,
            total: 0
        };
    },
    components: {
        Navigation,
    },
    methods: {
        handleSizeChange(size) {
            this.pageSize = size;
            this.fetchAVGScore();
        },
        handleCurrentChange(page) {
            this.currentPage = page;
            this.fetchAVGScore();
        },
        async fetchOptions() {
            let fetchFunction;
            if (this.selectedType === 'course') {
                fetchFunction = api.fetchCourse;
            } else if (this.selectedType === 'teacher') {
                fetchFunction = api.fetchTeachers;
            }

            try {
                const response = await fetchFunction(this.currentPage, 1000, '', 'all', '');
                if (response.data.code === 200) {
                    this.options = response.data.data.map(option => ({
                        id: option.id,
                        name: option.name
                    }));
                } else {
                    console.error('Failed to load options:', response.data.msg);
                }
            } catch (error) {
                console.error('Error during API call:', error);
            }
        },
        async fetchScore() {
            const term = this.selectedTerm;
            const type = this.selectedType || 'all';
            const condition = this.selectedOption || '';
            try {
                const response = await api.fetchScore(this.currentPage, this.pageSize, term, type, condition);
                if (response.data.code === 200) {
                    this.resultData = response.data.data.data;
                    this.total = response.data.data.total;
                } else {
                    console.error('Failed to load course data:', response.data.msg);
                }
            } catch (error) {
                console.error('Error during API call:', error);
            }
        },
        async fetchScore() {
            const term = this.selectedTerm;
            const type = this.selectedType || 'all';
            const condition = this.selectedOption || '';
            try {
                const response = await api.fetchScore(this.currentPage, this.pageSize, term, type, condition);
                if (response.data.code === 200) {
                    this.resultData = response.data.data.data;
                    this.total = response.data.data.total;
                } else {
                    console.error('Failed to load course data:', response.data.msg);
                }
            } catch (error) {
                console.error('Error during API call:', error);
            }
        },
        handleTypeChange() {
            this.selectedOption = '';
            this.options = [];
            this.fetchOptions();
        }
    },
    async mounted() {
        this.fetchScore();
    }
}
</script>

<style scoped>
.home-view {
    padding: 20px;
}

.large-text {
    font-size: 20px;
}
</style>