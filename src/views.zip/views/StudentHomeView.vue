<template>
    <NavigationStu>
        <div class="home-view">
            <el-row>
                <el-col :span="24">
                    <h1>欢迎你进入学生信息管理系统</h1>
                    <el-text class="large-text">{{ input }}</el-text>
                </el-col>
            </el-row>
        </div>
        <div class="main-container">
            <!-- 左侧：日历 -->
            <div class="calendar-section">
                <el-calendar v-model="value" />
            </div>

            <!-- 中间：考试信息 -->
            <div class="exam-section">
                <el-card class="exam-info-card">
                    <template #header>
                        <div class="card-header">
                            <span>📘 考试信息</span>
                        </div>
                    </template>
                    <div v-if="allexam.length > 0" class="exam-list">
                        <div
                            v-for="(exam, index) in allexam"
                            :key="index"
                            class="exam-item"
                        >
                            <div class="exam-course">课程: {{ exam.name }}</div>
                            <div class="exam-time">
                                考试时间:{{ formatExamDate(exam.examDate) }}
                            </div>
                            <div class="exam-location" v-if="exam.location">
                                地点: {{ exam.location }}
                            </div>
                            <el-divider v-if="index < allexam.length - 1" />
                        </div>
                    </div>
                    <div v-else class="no-exam">暂无考试信息</div>
                </el-card>
            </div>

            <!-- 右侧：快捷功能 -->
            <div class="action-section">
                <el-card>
                    <h3 style="margin-bottom: 20px">⚙️ 快捷操作</h3>
                    <el-button
                        type="primary"
                        @click="
                            clear_data();
                            dialogVisible = true;
                        "
                    >
                        修改密码
                    </el-button>
                </el-card>
                <el-card class="profile-card">
                    <div class="card-title">
                        <el-icon style="margin-right: 8px"><User /></el-icon>
                        👤 个人信息
                    </div>
                    <el-descriptions
                        :column="2"
                        border
                        class="profile-info"
                        size="default"
                    >
                        <el-descriptions-item label="姓名">{{
                            stu_info.name
                        }}</el-descriptions-item>
                        <el-descriptions-item label="班级">{{
                            stu_info.className
                        }}</el-descriptions-item>
                        <el-descriptions-item label="性别">{{
                            stu_info.gender
                        }}</el-descriptions-item>
                        <el-descriptions-item label="年龄">{{
                            stu_info.birthYear
                        }}</el-descriptions-item>
                        <el-descriptions-item label="学分">{{
                            stu_info.credits
                        }}</el-descriptions-item>
                        <el-descriptions-item label="家乡">{{
                            stu_info.hometown
                        }}</el-descriptions-item>
                    </el-descriptions>
                </el-card>
            </div>
        </div>

        <el-dialog title="表单弹框" v-model="dialogVisible" width="20%">
            <el-form ref="form" :model="form" :rules="rules" label-width="80px">
                <el-form-item label="旧密码" prop="oldpass">
                    <el-input v-model.number="form.oldpass"></el-input>
                </el-form-item>
                <el-form-item label="新密码" prop="newpass">
                    <el-input v-model="form.newpass"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="clear_data()">取消</el-button>
                <el-button
                    type="primary"
                    @click="
                        changepassword();
                        clear_data();
                    "
                    >确定</el-button
                >
            </span>
        </el-dialog>
    </NavigationStu>
</template>

<script>
import NavigationStu from "../components/NavigationStu.vue";
import api from "@/api/index.js";

// import * as echarts from "echarts";
export default {
    name: "AdminHomeView",
    components: {
        NavigationStu,
    },
    data() {
        return {
            user_id: "",
            dialogVisible: false,
            input: " ",
            myChart: {},
            allexam: [],
            stu_info: [],
            myChartStyle: { float: "left", width: "100%", height: "400px" },
            form: {
                oldpass: "",
                newpass: "",
            },
            rules: {
                old_pass: [
                    {
                        required: true,
                        message: "请输入旧密码",
                        trigger: "blur",
                    },
                ],
                new_pass: [
                    {
                        required: true,
                        message: "请输入新密码",
                        trigger: "blur",
                    },
                ],
            },
        };
    },
    methods: {
        formatExamDate(datetimeStr) {
            if (!datetimeStr) return "";
            return datetimeStr.replace("T", " ");
        },
        clear_data() {
            this.form.oldpass = "";
            this.form.newpass = "";
            this.dialogVisible = false;
        },
        async changepassword() {
            try {
                const response = await api.studentChangepPassword(
                    this.form.oldpass,
                    this.form.newpass
                );
                if (response.data.code === 200) {
                    this.$message.success("密码修改成功");
                } else {
                    this.$message.error("密码修改失败");
                }
            } catch (error) {
                console.error("请求失败", error);
                this.$message.error("请求过程中发生错误");
            }
        },
        async fetchStudentExamCourses() {
            try {
                const response = await api.fetchStudentExamCourses();
                console.log(response); // 检查返回结构

                if (response.data.code === 200) {
                    // 按照考试时间升序排序
                    const sortedData = response.data.data.sort(
                        (a, b) => new Date(a.examDate) - new Date(b.examDate)
                    );
                    this.allexam = sortedData;
                    console.log("考试信息加载成功", this.allexam);
                } else {
                    this.$message.error("加载考试信息失败！");
                }
            } catch (err) {
                console.error("API 调用失败", err);
                this.$message.error("系统异常！");
            }
        },
        async fetchStudentInfo() {
            try {
                const res = await api.fetchStudentInfo();
                console.log(res);

                if (res.data.code == 200) {
                    this.stu_info = res.data.data;
                } else {
                    this.$message.error("获取学生信息失败");
                }
            } catch (error) {
                console.error("获取学生信息失败", error);
                this.$message.error("系统异常，请稍后再试");
            }
        },
    },
    created() {},
    mounted() {
        this.fetchStudentExamCourses();
        this.fetchStudentInfo();
    },
};
</script>

<style>
.profile-card {
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    background-color: #fff;
}

.card-title {
    display: flex;
    align-items: center;
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333;
}

.profile-info {
    font-size: 16px;
}

.home-view {
    max-width: 60ch;
    margin: 0 auto;
}

.large-text {
    font-size: 25px;
    color: #36bcff;
}

.main-container {
    display: flex;
    justify-content: center;
    gap: 40px;
    margin-top: 50px;
    padding: 0 50px;
    flex-wrap: wrap;
}

.calendar-section,
.exam-section,
.action-section {
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    padding: 20px;
}

.calendar-section {
    width: 40%;
}

.exam-section {
    width: 30%;
}

.action-section {
    width: 20%;
    font-family: "Arial", sans-serif;
    font-size: 18px;
}

.exam-item {
    padding: 10px 0;
    line-height: 1.6;
}

.no-exam {
    text-align: center;
    color: #999;
    padding: 20px 0;
}
</style>
