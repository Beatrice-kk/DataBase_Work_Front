<template>
    <Navigation>
        <div class="home-view" activeIndex="1-4" key="nav">
            <el-row>
                <el-col :span="24">
                    <h1>查看生源所在地</h1>
                </el-col>
            </el-row>
        </div>

        <el-table
            :data="hometownCountData"
            stripe
            :style="{
                width: '15%',
                left: '50%',
                marginTop: '50px',
                position: 'relative',
                transform: 'translateX(-50%)',
            }"
        >
            <el-table-column
                prop="hometown"
                label="生源所在地"
                width="150"
            ></el-table-column>
            <el-table-column
                prop="count"
                label="学生数量"
                width="150"
            ></el-table-column>
            <el-table-column fixed="right" label="" min-width="10">
            </el-table-column>
        </el-table>

        <!-- 筛选条件输入框 -->
        <el-row
            :gutter="20"
            class="filter-row"
            :style="{
                width: '50%',
                left: '50%',
                marginTop: '50px',
                position: 'relative',
                transform: 'translateX(-10%)',
            }"
        >
            <el-col :span="3">
                <el-input
                    v-model="hometown"
                    placeholder="生源所在省"
                ></el-input>
            </el-col>
            <el-col :span="2">
                <el-button type="primary" @click="fetchStudents"
                    >查询</el-button
                >
            </el-col>
        </el-row>

        <el-table
            :data="studentData"
            stripe
            :style="{
                width: '50%',
                left: '50%',
                marginTop: '50px',
                position: 'relative',
                transform: 'translateX(-50%)',
            }"
        >
            <el-table-column
                prop="id"
                label="学号"
                width="150"
            ></el-table-column>
            <el-table-column
                prop="name"
                label="学生姓名"
                width="150"
            ></el-table-column>
            <el-table-column
                prop="gender"
                label="性别"
                width="150"
            ></el-table-column>
            <el-table-column
                prop="age"
                label="年龄"
                width="150"
            ></el-table-column>
            <el-table-column
                prop="hometown"
                label="生源地"
                width="150"
            ></el-table-column>
            <el-table-column
                prop="className"
                label="班级"
                width="150"
            ></el-table-column>
            <el-table-column
                prop="credits"
                label="所修学分"
                width="150"
            ></el-table-column>
            <el-table-column fixed="right" label="" min-width="10">
            </el-table-column>
        </el-table>

        <div
            class="demo-pagination-block"
            :style="{
                width: '40%',
                left: '50%',
                marginTop: '50px',
                position: 'relative',
                transform: 'translateX(-15%)',
            }"
        >
            <el-pagination
                v-model:current-page="currentPage"
                v-model:page-size="pageSize"
                :total="total"
                layout="prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
            />
        </div>
    </Navigation>
</template>

<script>
import Navigation from "../components/Navigation.vue";
import api from "@/api/index"; // 确保此路径和您项目的API路径一致

export default {
    data() {
        return {
            hometown: "",
            hometownCountData: [],
            studentData: [],
            currentPage: 1,
            pageSize: 10,
            total: 0,
        };
    },
    components: {
        Navigation,
    },
    methods: {
        handleSizeChange(size) {
            this.pageSize = size;
            this.fetchStudents();
        },
        handleCurrentChange(page) {
            this.currentPage = page;
            this.fetchStudents();
        },
        async fetchHometownCount() {
            try {
                const response = await api.hometownCount();
                if (response.data.code === 200) {
                    this.hometownCountData = response.data.data;
                } else {
                    this.$message.error("系统异常");
                }
            } catch (error) {
                console.error("Error during API call:", error);
            }
        },
        async fetchStudents() {
            try {
                const response = await api.getHometownStudent(
                    this.currentPage,
                    this.pageSize,
                    this.hometown
                );
                if (response.data.code === 200) {
                    const data = response.data.data.data;
                    this.studentData = data.map((student) => ({
                        ...student,
                        age: 2023 - Number(student.birthYear) + 1,
                    }));
                    this.total = response.data.data.total;
                } else {
                    this.$message.error("系统异常");
                }
            } catch (error) {
                console.error("Error during API call:", error);
            }
        },
    },
    async mounted() {
        this.fetchHometownCount();
    },
};
</script>

<style scoped>
.home-view {
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.el-table {
    margin-top: 20px;
    width: 80%;
}

.filter-row {
    margin-top: 20px;
    width: 80%;
    display: flex;
    justify-content: center;
}

.demo-pagination-block {
    margin-top: 20px;
    width: 80%;
    display: flex;
    justify-content: center;
}

.large-text {
    font-size: 20px;
    text-align: center;
}
</style>
