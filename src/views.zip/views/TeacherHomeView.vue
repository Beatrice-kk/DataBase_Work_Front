<template>
    <NavigationTea>
        <div class="home-view">
            <el-row>
                <el-col :span="24">
                    <h1>欢迎你进入学生信息管理系统</h1>
                    <el-text class="large-text">{{ input }}</el-text>
                </el-col>
            </el-row>
        </div>
        <div class="main-container">
            <!-- 左侧：日历 -->
            <div class="calendar-section">
                <el-calendar v-model="value" />
            </div>

            <!-- 中间：考试信息 -->
            <div class="exam-section">
                <el-card class="exam-info-card">
                    <template #header>
                        <div class="card-header">
                            <span>📘 考试信息</span>
                        </div>
                    </template>
                    <div v-if="allexam.length > 0" class="exam-list">
                        <div
                            v-for="(exam, index) in allexam"
                            :key="index"
                            class="exam-item"
                        >
                            <div class="exam-course">
                                📚 课程: {{ exam.name }}
                            </div>
                            <div class="exam-time">
                                🕒 时间: {{ formatExamDate(exam.examDate) }}
                            </div>
                            <div class="exam-location" v-if="exam.location">
                                📍 地点: {{ exam.location }}
                            </div>
                            <el-divider v-if="index < allexam.length - 1" />
                        </div>
                    </div>
                    <div v-else class="no-exam">暂无考试信息</div>
                </el-card>
            </div>

            <!-- 右侧：快捷功能 -->
            <div class="action-section">
                <!-- 快捷操作 -->
                <el-card>
                    <h3 style="margin-bottom: 20px">⚙️ 快捷操作</h3>
                    <el-button
                        type="primary"
                        @click="
                            clear_data();
                            dialogVisible = true;
                        "
                    >
                        修改密码
                    </el-button>
                </el-card>

                <!-- 教师信息 -->
                <el-card class="profile-card">
                    <div class="card-title">
                        <el-icon style="margin-right: 8px"><User /></el-icon>
                        👨‍🏫 教师信息
                    </div>
                    <el-descriptions
                        :column="2"
                        border
                        class="profile-info"
                        size="default"
                    >
                        <el-descriptions-item label="姓名">
                            {{ teacher_info.name }}
                        </el-descriptions-item>
                        <el-descriptions-item label="工号">
                            {{ teacher_info.id }}
                        </el-descriptions-item>
                        <el-descriptions-item label="性别">
                            {{ teacher_info.gender }}
                        </el-descriptions-item>
                        <el-descriptions-item label="出生年份">
                            {{ teacher_info.birthYear }}
                        </el-descriptions-item>
                        <el-descriptions-item label="职称">
                            {{ teacher_info.jobTitle }}
                        </el-descriptions-item>
                        <el-descriptions-item label="学院">
                            {{ teacher_info.college }}
                        </el-descriptions-item>
                        <el-descriptions-item label="联系方式">
                            {{ teacher_info.phone }}
                        </el-descriptions-item>
                    </el-descriptions>
                </el-card>
            </div>
        </div>

        <el-dialog title="表单弹框" v-model="dialogVisible" width="20%">
            <el-form ref="form" :model="form" :rules="rules" label-width="80px">
                <el-form-item label="旧密码" prop="oldpass">
                    <el-input v-model.number="form.oldpass"></el-input>
                </el-form-item>
                <el-form-item label="新密码" prop="newpass">
                    <el-input v-model="form.newpass"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="clear_data()">取消</el-button>
                <el-button
                    type="primary"
                    @click="
                        changepassword();
                        clear_data();
                    "
                    >确定</el-button
                >
            </span>
        </el-dialog>
    </NavigationTea>
</template>

<script>
import NavigationTea from "../components/NavigationTea.vue";
import api from "@/api/index.js";
// import * as echarts from "echarts";
export default {
    name: "AdminHomeView",
    components: {
        NavigationTea,
    },
    // 在data()函数中添加
    data() {
        return {
            allexam: [],
            teacher_info: [],
            user_id: "",
            dialogVisible: false,
            input: " ",
            myChart: {},
            allexam: [],
            myChartStyle: { float: "left", width: "100%", height: "400px" },
            form: {
                oldpass: "",
                newpass: "",
            },
            rules: {
                old_pass: [
                    {
                        required: true,
                        message: "请输入旧密码",
                        trigger: "blur",
                    },
                ],
                new_pass: [
                    {
                        required: true,
                        message: "请输入新密码",
                        trigger: "blur",
                    },
                ],
            },
            value: new Date(),
            examList: [],
        };
    },
    // 在methods中添加新方法
    methods: {
        formatExamDate(datetimeStr) {
            if (!datetimeStr) return "";
            return datetimeStr.replace("T", " ");
        },
        clear_data() {
            this.form.oldpass = "";
            this.form.newpass = "";
            this.dialogVisible = false;
        },
        async changepassword() {
            try {
                const response = await api.teacherChangepPassword(
                    this.form.oldpass,
                    this.form.newpass
                );
                if (response.data.code === 200) {
                    this.$message.success("密码修改成功");
                } else {
                    this.$message.error("密码修改失败");
                }
            } catch (error) {
                console.error("请求失败", error);
                this.$message.error("请求过程中发生错误");
            }
        },
        async fetchExamDates() {
            try {
                // 尝试从后端获取考试日期数据
                const response = await api.getTeacherExamDates();
                if (response && response.data && response.data.code === 200) {
                    this.examList = response.data.data;
                } else {
                    // 如果后端接口未实现或返回错误，使用模拟数据
                    console.warn("使用模拟考试数据");
                    this.examList = [
                        {
                            date: "2023-06-15",
                            courseName: "数据库原理",
                            location: "教学楼101",
                        },
                        {
                            date: "2023-06-20",
                            courseName: "操作系统",
                            location: "教学楼202",
                        },
                        {
                            date: "2023-06-25",
                            courseName: "计算机网络",
                            location: "教学楼303",
                        },
                    ];
                }
            } catch (error) {
                console.error("获取考试日期失败", error);
                // 发生错误时使用模拟数据
                this.examList = [
                    {
                        date: "2023-06-15",
                        courseName: "数据库原理",
                        location: "教学楼101",
                    },
                    {
                        date: "2023-06-20",
                        courseName: "操作系统",
                        location: "教学楼202",
                    },
                    {
                        date: "2023-06-25",
                        courseName: "计算机网络",
                        location: "教学楼303",
                    },
                ];
            }
        },

        async fetchTeacherExamCourses() {
            try {
                const response = await api.fetchTeacherExamCourses();
                console.log(response); // 检查返回结构

                if (response.data.code === 200) {
                    // 按照考试时间升序排序
                    const sortedData = response.data.data.sort(
                        (a, b) => new Date(a.examDate) - new Date(b.examDate)
                    );
                    this.allexam = sortedData;
                    console.log("考试信息加载成功", this.allexam);
                } else {
                    this.$message.error("加载考试信息失败！");
                }
            } catch (err) {
                console.error("API 调用失败", err);
                this.$message.error("系统异常！");
            }
        },
        async fetchTeacherInfo() {
            try {
                const res = await api.fetchTeacherInfo();
                console.log("教师信息返回：", res);

                if (res.data && res.data.code === 200) {
                    this.teacher_info = res.data.data;
                } else {
                    this.$message.error("教师信息加载失败！");
                }
            } catch (error) {
                console.error("请求教师信息失败：", error);
                this.$message.error("系统异常！");
            }
        },

        hasExam(day) {
            return this.examList.some((exam) => exam.date === day);
        },
        getExamInfo(day) {
            const exam = this.examList.find((exam) => exam.date === day);
            return exam ? `${exam.courseName} (${exam.location})` : "";
        },
    },
    // 在created钩子中调用
    created() {
        this.fetchExamDates();
    },
    mounted() {
        this.fetchTeacherExamCourses();
        this.fetchTeacherInfo();
    },
};
</script>

<style>
.home-view {
    max-width: 1200px;
    margin: 0 auto;
    text-align: center;
}

.large-text {
    font-size: 24px;
    color: #409eff;
    margin-top: 10px;
    display: inline-block;
}

.exam-date {
    color: #f56c6c;
    font-size: 12px;
    margin-top: 4px;
}
</style>
