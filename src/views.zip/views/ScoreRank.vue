<template>
    <Navigation>
        <div class="home-view" activeIndex="1-4" key="nav">
            <el-row>
                <el-col :span="24">
                    <h1>学年成绩排名查询</h1>
                </el-col>
            </el-row>
        </div>

        <!-- 筛选条件输入框 -->
        <el-row :gutter="20" class="filter-row"
            :style="{ width: '60%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-35%)' }">
            <el-col :span="4">
                <el-select v-model="selectedYear" placeholder="选择学年">
                    <el-option label="2021" value="2021"></el-option>
                    <el-option label="2022" value="2022"></el-option>
                    <el-option label="2023" value="2023"></el-option>
                    <el-option label="2024" value="2024"></el-option>
                </el-select>
            </el-col>
            <el-col :span="6">
                <el-select v-model="selectedMajor" placeholder="选择专业" @change="fetchClasses">
                    <el-option v-for="option in majors" :key="option.id" :label="option.name"
                        :value="option.name"></el-option>
                </el-select>
            </el-col>
            <el-col :span="4">
                <el-select v-model="selectedClass" placeholder="选择班级" :disabled="!selectedMajor">
                    <el-option label="全部" value="全部"></el-option>
                    <el-option v-for="option in classes" :key="option.id" :label="option.name"
                        :value="option.name"></el-option>
                </el-select>
            </el-col>
            <el-col :span="4">
                <el-button type="primary" @click="fetchScores">查询</el-button>
            </el-col>
        </el-row>

        <el-table :data="scoreData" stripe
            :style="{ width: '35%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-50%)' }">
            <el-table-column prop="student_id" label="学生学号" width="150"></el-table-column>
            <el-table-column prop="student_name" label="学生姓名" width="150"></el-table-column>
            <el-table-column prop="gpa" label="成绩" width="150"></el-table-column>
            <el-table-column prop="credit" label="所修学分" width="150"></el-table-column>
            <el-table-column prop="rank" label="排名" width="150"></el-table-column>
            <el-table-column fixed="right" label="" min-width="10">
            </el-table-column>
        </el-table>

        <div class="demo-pagination-block"
            :style="{ width: '40%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-15%)' }">
            <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :total="total"
                layout="prev, pager, next, jumper" @size-change="handleSizeChange"
                @current-change="handleCurrentChange" />
        </div>
    </Navigation>
</template>

<script>
import Navigation from '../components/Navigation.vue'
import api from '@/api/index' // 确保此路径和您项目的API路径一致

export default {
    data() {
        return {
            selectedYear: '',
            selectedMajor: '',
            selectedClass: '全部',
            majors: [],
            classes: [],
            scoreData: [],
            currentPage: 1,
            pageSize: 10,
            total: 0
        };
    },
    components: {
        Navigation,
    },
    methods: {
        handleSizeChange(size) {
            this.pageSize = size;
            this.fetchScores();
        },
        handleCurrentChange(page) {
            this.currentPage = page;
            this.fetchScores();
        },
        async fetchMajors() {
            try {
                const response = await api.fetchMajors(1, 100, 'all', '');
                if (response.data.code === 200) {
                    this.majors = response.data.data.data.map(option => ({
                        id: option.id,
                        name: option.name
                    }));
                } else {
                    console.error('Failed to load majors:', response.data.msg);
                }
            } catch (error) {
                console.error('Error during API call:', error);
            }
        },
        async fetchClasses() {
            const major = this.selectedMajor;
            try {
                const response = await api.fetchClass(1, 100, 'major', major);
                if (response.data.code === 200) {
                    this.classes = response.data.data.data.map(option => ({
                        id: option.id,
                        name: option.name
                    }));
                } else {
                    console.error('Failed to load classes:', response.data.msg);
                }
            } catch (error) {
                console.error('Error during API call:', error);
            }
        },
        async fetchScores() {
            const year = this.selectedYear;
            let type = '';
            let condition = '';
            if (this.selectedClass === '全部') {
                type = 'major';
                condition = this.selectedMajor;
            } else {
                type = 'class';
                condition = this.selectedClass;
            }
            try {
                const response = await api.fetchScoreAllYear(year, type, condition);
                if (response.data.code === 200) {
                    const data = response.data.data.data;
                    data.sort((a, b) => b.gpa - a.gpa);
                    data.forEach((v, i) => {
                        v.gpa = Number(v.gpa);
                        if (v.gpa < 50) {
                            v.gpa = 0.0;
                        } else {
                            v.gpa = (v.gpa - 50) / 10;
                        }
                        v.rank = i + 1;
                    });
                    this.scoreData = data;
                    this.total = data.length;
                } else {
                    console.error('Failed to load scores:', response.data.msg);
                }
            } catch (error) {
                console.error('Error during API call:', error);
            }
        }
    },
    async mounted() {
        this.fetchMajors();
    }
}
</script>

<style scoped>
.home-view {
    padding: 20px;
}

.large-text {
    font-size: 20px;
}
</style>