<template>
    <Navigation>
        <div class="home-view" activeIndex="1-4" key="nav">
            <el-row>
                <el-col :span="24">
                    <h1>成绩查询</h1>
                </el-col>
            </el-row>
        </div>

        <!-- 筛选条件输入框 -->
        <el-row :gutter="20" class="filter-row"
            :style="{ width: '80%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-20%)' }">
            <el-col :span="4">
                <el-select v-model="selectedType" placeholder="选择类型" @change="handleTypeChange">
                    <el-option label="课程名称" value="course"></el-option>
                    <el-option label="任课教师" value="teacher"></el-option>
                </el-select>
            </el-col>
            <el-col :span="4">
                <el-select v-model="selectedOption" placeholder="选择选项" :disabled="!selectedType">
                    <el-option v-for="option in options" :key="option.id" :label="option.name"
                        :value="option.id"></el-option>
                </el-select>
            </el-col>
            <el-col :span="4">
                <el-button type="primary" @click="fetchAVGScoreFind">搜索</el-button>
            </el-col>
        </el-row>

        <el-table :data="courseData" stripe
            :style="{ width: '45%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-50%)' }">
            <el-table-column prop="course_id" label="课程编号" width="150"></el-table-column>
            <el-table-column prop="course_name" label="课程名称" width="180"></el-table-column>
            <el-table-column prop="teacher_id" label="教师编号" width="150"></el-table-column>
            <el-table-column prop="teacher_name" label="教师姓名" width="150"></el-table-column>
            <el-table-column prop="term" label="开设学期" width="180"></el-table-column>
            <el-table-column prop="score" label="平均成绩" width="150"></el-table-column>
            <el-table-column fixed="right" label="" min-width="10">
            </el-table-column>
        </el-table>

        <div class="demo-pagination-block"
            :style="{ width: '50%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-50%)' }">
            <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :size="size"
                :disabled="disabled" :background="background" layout="prev, pager, next, jumper" :total="total"
                @size-change="handleSizeChange" @current-change="handleCurrentChange"
                :style="{ width: '50%', left: '50%', marginTop: '50px', position: 'relative', transform: 'translateX(-20%)' }" />
        </div>
    </Navigation>
</template>

<script>
import Navigation from '../components/Navigation.vue'
import api from '@/api/index' // 确保此路径和您项目的API路径一致

export default {
    data() {
        return {
            selectedType: '',
            selectedOption: '',
            options: [],
            courseData: [],
            currentPage: 1,
            pageSize: 10,
            total: 0
        };
    },
    components: {
        Navigation,
    },
    methods: {
        handleSizeChange(size) {
            this.pageSize = size;
            this.fetchAVGScore();
        },
        handleCurrentChange(page) {
            this.currentPage = page;
            this.fetchAVGScore();
        },
        async fetchOptions() {
            let fetchFunction;
            if (this.selectedType === 'course') {
                fetchFunction = api.fetchCourse;
            } else if (this.selectedType === 'teacher') {
                fetchFunction = api.fetchTeachers;
            }

            try {
                const response = await fetchFunction(this.currentPage, 1000, 'all', '');
                if (response.data.code === 200) {
                    this.options = response.data.data.data.map(option => ({
                        id: option.id,
                        name: option.name
                    }));
                } else {
                    console.error('Failed to load options:', response.data.msg);
                }
            } catch (error) {
                console.error('Error during API call:', error);
            }
        },
        async fetchAVGScore() {
            const type = this.selectedType || 'all';
            const condition = this.selectedOption || '';
            try {
                const response = await api.fetchAVGScore(this.currentPage, this.pageSize, type, condition);
                if (response.data.code === 200) {
                    this.courseData = response.data.data.data;
                    this.total = response.data.data.total;
                    console.log(this.courseData);
                } else {
                    console.error('Failed to load course data:', response.data.msg);
                }
            } catch (error) {
                console.error('Error during API call:', error);
            }
        },

        async fetchAVGScoreFind() {
            var type = this.selectedType || 'all';
            const condition = this.selectedOption || '';
            if (condition === '')
                type = 'all';
            try {
                const response = await api.fetchAVGScore(this.currentPage, this.pageSize, type, condition);
                if (response.data.code === 200) {
                    this.courseData = response.data.data.data;
                    this.total = response.data.data.total;
                    console.log(this.courseData);
                } else {
                    console.error('Failed to load course data:', response.data.msg);
                }
            } catch (error) {
                console.error('Error during API call:', error);
            }
        },
        handleTypeChange() {
            this.selectedOption = '';
            this.options = [];
            this.fetchOptions();
        }
    },
    async mounted() {
        this.fetchAVGScore();
    },
}
</script>

<style scoped>
.home-view {
    padding: 20px;
}

.large-text {
    font-size: 20px;
}
</style>
