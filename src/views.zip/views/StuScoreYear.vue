<template>
    <NavigationStu>
        <div class="home-view" activeIndex="1-4" key="nav">
            <el-row>
                <el-col :span="24">
                    <h1>查询学年总成绩</h1>
                </el-col>
            </el-row>
        </div>

        <el-table
            :data="scoreData"
            stripe
            :style="{
                width: '50%',
                left: '50%',
                marginTop: '40px',
                position: 'relative',
                transform: 'translateX(-50%)',
            }"
        >
            <el-table-column
                prop="year"
                label="学年"
                width="150"
            ></el-table-column>
            <el-table-column
                prop="gpa"
                label="绩点"
                width="150"
            ></el-table-column>
            <el-table-column
                prop="credit"
                label="学分"
                width="120"
            ></el-table-column>
            <el-table-column fixed="right" label="" min-width="10">
            </el-table-column>
        </el-table>

        <div
            class="demo-pagination-block"
            :style="{
                width: '40%',
                left: '50%',
                marginTop: '50px',
                position: 'relative',
                transform: 'translateX(-15%)',
            }"
        >
            <el-pagination
                v-model:current-page="currentPage"
                v-model:page-size="pageSize"
                :total="total"
                layout="prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
            />
        </div>
    </NavigationStu>
</template>

<script>
import NavigationStu from "../components/NavigationStu.vue";
import api from "@/api/index"; // 确保此路径和您项目的API路径一致

export default {
    data() {
        return {
            currentPage: 1,
            pageSize: 10,
            scoreData: [],
            total: 0,
        };
    },
    components: {
        NavigationStu,
    },
    methods: {
        handleSizeChange(size) {
            this.pageSize = size;
            this.fetchScores();
        },
        handleCurrentChange(page) {
            this.currentPage = page;
            this.fetchScores();
        },
        async fetchScores() {
            try {
                const response = await api.studentGetAllScore();
                if (response.data.code === 200) {
                    const data = response.data.data;
                    data.forEach((v) => {
                        v.gpa = Number(v.gpa);
                        if (v.gpa < 50) {
                            v.gpa = 0.0;
                        } else {
                            v.gpa = (v.gpa - 50) / 10;
                        }
                    });
                    this.scoreData = data;
                    this.total = response.data.total;
                } else {
                    this.$message.error("系统异常");
                }
            } catch (error) {
                console.error("Error during API call:", error);
            }
        },
    },
    mounted() {
        this.fetchScores();
    },
};
</script>

<style scoped>
.home-view {
    padding: 20px;
}

.large-text {
    font-size: 20px;
}
</style>
